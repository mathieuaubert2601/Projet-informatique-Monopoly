#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <windows.h>


int f13(joueur.position,/*coord des spatioports*/){

system("cls");

printf("                               -d@E_                              \n");
printf("         J E D I  1 3         _D@@@B~                             \n");
printf("                             ]@@@@@@@V`                           \n");
printf("               `^,         `V@@@@@@@@@W.         -^`              \n");
printf("              ~q?          '8@@@@@@@@@Q_          :Zr             \n");
printf("            'z#!            -Q@@@@@@@#:            'R6:           \n");
printf("           ~Q@?         ^Wv  v@@@@@@@z  <Wx         _@#l`         \n");
printf("          r#@8        `u@@@K_.Q@@@@@#,`n@@@V`        l@@W-        \n");
printf("        `H@@#:       ,N@@@@@@]z@@@@@q^B@@@@@B=        s@@B^       \n");
printf("       `5@@@V        'vD@@@@@@B@@@@@Q@@@@@@0v'        _#@@#<      \n");
printf("       o@@@#_          `rB@@@@@@@@@@@@@@@#x`           z@@@#=     \n");
printf("      t@@@@V             `t@@@@@@@@@@@@@W.             ,#@@@#:    \n");
printf("     ^@@@@@>              `Q@@@@@@@@@@@#`               E@@@@6`   \n");
printf("    .8@@@@B.               |@@@@@@@@@@@}                V@@@@@(   \n");
printf("    z@@@@@$                 P@@@@@@@@@0`                n@@@@@#-  \n");
printf("   _#@@@@@$                 *@@@@@@@@@}                 n@@@@@@i  \n");
printf("   i@@@@@@$                 `Q@@@@@@@@~                 h@@@@@@d  \n");
printf("   R@@@@@@@:                 K@@@@@@@8`                `Q@@@@@@@! \n");
printf("   #@@@@@@@i                 n@@@@@@@0                 ?@@@@@@@@x \n");
printf("  ^@@@@@@@@0`                J@@@@@@@0                `6@@@@@@@@z \n");
printf("  n@@@@@@@@@j                D@@@@@@@#_               V@@@@@@@@@N \n");
printf("  n@@@@@@@@@@(              ,#@@@@@@@@r              r@@@@@@@@@@0 \n");
printf("  n@@@@@@@@@@@^             G@@@@@@@@@D`            =@@@@@@@@@@@0 \n");
printf("  n@@@@@@@@@@@#|           ?@@@@@@@@@@@n           ^B@@@@@@@@@@@$ \n");
printf("  v@@@@@@@@@@@@@Z=        !#@@@@@@@@@@@@^        ,a@@@@@@@@@@@@@P \n");
printf("  !@@@@@@@@@@@@@@@#S]^=rn8@@@@@@@@@@@@@@@Qn*:=?yQ@@@@@@@@@@@@@@@c \n");
printf("  `Q@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@< \n");
printf("   a@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@B. \n");
printf("   !@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@z  \n");
printf("    Z@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@#=  \n");
printf("    ^@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@5   \n");
printf("     V@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@#,   \n");
printf("     .8@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@}    \n");
printf("      =#@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@6`    \n");
printf("       =#@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@E`     \n");
printf("        ~#@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@8_      \n");
printf("         ~B@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@8,       \n");
printf("          `w@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@V`        \n");
printf("            ?B@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@Br          \n");
printf("             _Q@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@b_           \n");
printf("               ~Z@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@E<             \n");
printf("                 !m#@@@@@@@@@@@@@@@@@@@@@@@@@@@@@q^               \n");
printf("                   -]6#@@@@@@@@@@@@@@@@@@@@@@@Ru:                 \n");
printf("                       ,?jE#@@@@@@@@@@@@QEw|:                     \n");
printf("                           .:<vvvvvvv|~:                   \n");

gotoligcol(22,115);
printf(" C A R T E  J E D I :");

gotoligcol(24,95);
printf(" A L L E Z  A U  S P A T I O P O R T  L E  P L U S  P R O C H E");



gotoligcol(26,90);
Color(10,0);

for (int i=0;i<75;i++)
{
    Sleep(20);
    printf("_");
}
gotoligcol(45,00);
for (int i=0;i<168;i++)
{
    Sleep(20);
    printf(".");
}
tabdist=[distance1,distance2,distance3,distance4]
distance1=sqrt(((Xjoueur-Xspatioport1)**2)+((Yjoueur-Yspatioport1)**2));
distance2=sqrt(((Xjoueur-Xspatioport2)**2)+((Yjoueur-Yspatioport2)**2));
distance3=sqrt(((Xjoueur-Xspatioport3)**2)+((Yjoueur-Yspatioport3)**2));
distance4=sqrt(((Xjoueur-Xspatioport4)**2)+((Yjoueur-Yspatioport4)**2));
distmin=0;
for (i=0;i<4,i++){
    if tab[i]>tab[i+1]{
        distmin=tab[i+1];
    }
}

}

