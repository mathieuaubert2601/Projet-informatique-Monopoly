#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <windows.h>


int f(){

system("cls");
printf(" ______________________________________");
printf("\n");
printf("| *          carte chance             *|");
printf("\n");
printf("|                                      |");
printf("\n");
printf("|                                      |");
printf("\n");
printf("|                                      |");
printf("\n");
printf("|                                      |");
printf("\n");
printf("|                                      |");
printf("\n");
printf("|                                      |");
printf("\n");
printf("|*____________________________________*|");
}
