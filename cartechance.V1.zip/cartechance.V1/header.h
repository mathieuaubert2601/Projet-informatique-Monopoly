#ifndef HEADER_H_INCLUDED
#define HEADER_H_INCLUDED

int f1(joueur.argent);
int f2(joueur.argent);
int f3(joueur.argent);
int f4(joueur.position);
int f5(joueur.position);
int f6(joueur.position);
int f7(joueur.argent);
int f8(joueur.argent);
int f9(joueur.argent);
int f10(joueur.position);
int f11(joueur.argent);
int f12(joueur.argent);
int f13(joueur.position);
int f14(joueur.position);
int f15(joueur.position);
int f16(joueur.position);
void gotoligcol( int lig, int col );
void Color(int couleurDuTexte,int couleurDeFond);











#endif // HEADER_H_INCLUDED
