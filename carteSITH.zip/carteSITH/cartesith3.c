#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <windows.h>


joueur_t Fsith3(joueur_t joueur, /*structure d'une propri�t�*/)
{
printf("                              ,ooo888888888888888oooo,\n");
printf("                            o8888YYYYYY77iiiiooo8888888o\n");
Sleep(30);
printf("                           8888YYYY77iiYY8888888888888888\n");
printf("                         [88YYY77iiY88888888888888888888]\n");
Sleep(30);
printf("         S I T H    3    88YY7iYY888888888888888888888888\n");
printf("                        [88YYi 88888888888888888888888888]\n");
Sleep(30);
printf("                        i88Yo8888888888888888888888888888i\n");
printf("                        i]        ^^^88888888^^^     o  [i\n");
Sleep(30);
printf("                       oi8  i           o8o          i  8io\n");
printf("                      ,77788o ^^  ,oooo8888888ooo,   ^ o88777,\n");
Sleep(30);
printf("                      7777788888888888888888888888888888877777\n");
printf("                       77777888888888888888888888888888877777\n");
Sleep(30);
printf("                        77777788888888^7777777^8888888777777\n");
printf("         ,oooo888 ooo   88888778888^7777ooooo7777^8887788888        ,o88^^^^888oo    \n");
Sleep(30);
printf("        o8888777788[];78 88888888888888888888888888888888888887 7;8^ 888888888oo^88   \n");
printf("      o888888iii788 ]; o 78888887788788888^;;^888878877888887 o7;[]88888888888888o    \n");
Sleep(30);
printf("     88888877 ii78[]8;7o 7888878^ ^8788^;;;;;;^878^ ^878877 o7;8 ]878888888888888    \n");
printf("    [88888888887888 87;7oo 777888o8888^;ii;;ii;^888o87777 oo7;7[]8778888888888888   \n");
Sleep(30);
printf("    88888888888888[]87;777oooooooooooooo888888oooooooooooo77;78]88877i78888888888  \n");
printf("   o88888888888888 877;7877788777iiiiiii;;;;;iiiiiiiii77877i;78] 88877i;788888888     \n");
Sleep(30);
printf("    88^;iiii^88888 o87;78888888888888888888888888888888888887;778] 88877ii;7788888     \n");
printf("   ;;;iiiii7iiii^  87;;888888888888888888888888888888888888887;778] 888777ii;78888                                     C A R T E  S I T H : \n");
Sleep(30);
printf("   ;iiiii7iiiii7iiii77;i88888888888888888888i7888888888888888877;77i 888877777ii78\n");
Color(15,0);
printf("   iiiiiiiiiii7iiii7iii;;;i7778888888888888ii7788888888888777i;;;;iiii 88888888888                I N F I L T R E Z  V IO U S : P I O C H E Z  U N E  C A R T E  J E D I \n");
Sleep(30);
printf("     i;iiiiiiiiiiii7iiiiiiiiiiiiiiiiiiiiiiiiii8877iiiiiiiiiiiiiiiiiii877   88888      \n");
printf("      ii;;iiiiiiiiiiiiii;;;ii^^^;;;ii77777788888888888887777iii;;  77777           78                   \n");
Sleep(30);
printf("     77iii;;iiiiiiiiii;;;ii;;;;;;;;;^^^^8888888888888888888777ii;;  ii7         ;i78\n");
printf("        ^ii;8iiiiiiii ';;;;ii;;;;;;;;;;;;;;;;;;^^oo ooooo^^^88888888;;i7          7;788\n");
Sleep(30);
printf("      o ^;;^^88888^     'i;;;;;;;;;;;;;;;;;;;;;;;;;;;^^^88oo^^^^888ii7         7;i788\n");
printf("    88ooooooooo         ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;; 788oo^;;          7;i888\n");
Sleep(30);
printf("      887ii8788888      ;;;;;;;ii;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;^87           7;788\n");
printf("      887i8788888^     ;;;;;;;ii;;;;;;;oo;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;,,,      ;;888\n");
Sleep(30);
printf("      87787888888     ;;;;;;;ii;;;;;;;888888oo;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;,,;i788\n");
printf("     87i8788888^       ';;;ii;;;;;;;8888878777ii8ooo;;;;;;;;;;;;;;;;;;;;;;;;;;i788 7\n");
Sleep(30);
printf("    77i8788888           ioo;;;;;;oo^^ooooo ^7i88^ooooo;;;;;;;;;;;;;;;;;;;;i7888 78\n");
printf("   7i87788888o         7;ii788887i7;7;788888ooooo7888888ooo;;;;;;;;;;;;;;oo ^^^ 78\n");
Sleep(30);
printf("   i; 7888888^      8888^o;ii778877;7;7888887;;7;7788878;878;;    ;;;;;;;i78888o ^\n");
printf("  i8 788888       [88888^^ ooo ^^^^^;;77888^^^^;;7787^^^^ ^^;;;;  iiii;i78888888\n");
Sleep(30);
printf(" ^8 7888^        [87888 87 ^877i;i8ooooooo8778oooooo888877ii; iiiiiiii788888888\n");
printf("  ^^^          [7i888 87;; ^8i;;i7888888888888888887888888   i7iiiiiii88888^^\n");
Sleep(30);
printf("               87;88 o87;;;;o 87i;;;78888788888888888888^^ o 8ii7iiiiii;;\n");
printf("               87;i8 877;77888o ^877;;;i7888888888888^^ 7888 78iii7iii7iiii\n");
Sleep(30);
printf("               ^87; 877;778888887o 877;;88888888888^ 7ii7888 788oiiiiiiiii\n");
printf("                 ^ 877;7 7888888887 877i;;8888887ii 87i78888 7888888888\n");
Sleep(30);
printf("                  [87;;7 78888888887 87i;;888887i  87ii78888 7888888888]");
gotoligcol(28,95);
Color(12,0);
for (int i=0;i<72;i++)
{
    Sleep(20);
    printf("_");
}
gotoligcol(45,00);
for (int i=0;i<168;i++)
{
    Sleep(20);
    printf(".");
}

joueur_t cartejedi(joueur_t joueur, /*structure d'une propri�t�*/);
return joueur_t;

}

