#ifndef HEADER_H_INCLUDED
#define HEADER_H_INCLUDED

void cartesith();
void Color(int couleurDuTexte,int couleurDeFond);
void gotoligcol( int lig, int col );
int Fsith1(joueur.position);
int Fsith2(joueur.argent);
joueur_t Fsith3(joueur_t joueur, /*structure d'une propri�t�*/);
int Fsith4(joueur.position);
int Fsith5(joueur.argent);
int Fsith6(joueur.argent);
int Fsith7(joueur.argent);
int Fsith8(joueur.position);
int Fsith9(joueur.position);
int Fsith10(joueur.argent);
int Fsith11(joueur.argent);
int Fsith12(joueur.argent);
int Fsith13(joueur.argent);
int Fsith14(joueur.libertePrison);
int Fsith15(joueur.argent);
int Fsith16(joueur.position);

#endif // HEADER_H_INCLUDED
